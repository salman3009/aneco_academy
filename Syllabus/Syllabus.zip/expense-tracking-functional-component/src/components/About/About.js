import './About.css';
import dash from '../../assets/image/dash.PNG';
const About=()=>{
   return (<div>
        <div className="container">
            <div className="row">
                <div className="col-12">
                 <img src={dash}/>
                </div>
          
            </div>
        </div>
   </div>)

}
export default About;
