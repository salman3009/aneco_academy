export const registerValidationError={
fullName:"FullName should be alphanumeric",
lastName:"lastName should be alphanumeric",
email:"email should be valid one",
password:"password should be alphanumeric and following symbol(_-&#@)",
sessionDetails:"email and password not found"
}

export const expenseValidationError={
    expenseName:"cannot be empty",
    amount:"cannot be empty",
    paidBy:"cannot be empty",
    date:"cannot be empty"
}

