import Login from './Login/Login';
import Register from './Register/Register';
import Table from './Table/Table';
function App() {
  return (
    <div >
     <Login/>
     {/* <Register/> */}
     {/* <Table/> */}
    </div>
  );
}

export default App;
