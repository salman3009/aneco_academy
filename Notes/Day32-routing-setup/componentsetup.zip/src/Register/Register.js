import './Register.css';
import Header from '../Header/Header';
const Register=()=>{

    return (<div>
      <Header/>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="text-center">
          <h1>Sign up</h1>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">

      </div>
      <div class="col-md-4">
        <form>
          <div class="form-group">
            <label for="exampleInputEmail1">First Name</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
              placeholder="Enter email"/>

          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Last Name</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
              placeholder="Enter email"/>

          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
              placeholder="Enter email"/>

          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
          </div>
          <div class="row">
            <div class="col-12">
              <div class="text-center">
                <button type="submit" class="btn btn-outline-success">Submit</button>
              </div>

            </div>
          </div>

        </form>
      </div>
      <div class="col-md-4">

      </div>
    </div>
  </div>
    </div>)
}
export default Register;