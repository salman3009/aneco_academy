import Login from './Login/Login';
import Register from './Register/Register';
import Table from './Table/Table';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
function App() {
  return (
    <div >
      <BrowserRouter>
      <Routes>
        <Route path='' element={  <Register/>}/>
        <Route path='login' element={  <Login/>}/>
        <Route path='table' element={  <Table/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
