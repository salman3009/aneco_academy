import './Header.css';
import download from '../assets/image/download.jpg';
import { Link } from 'react-router-dom';
const Header=()=>{
   return ( <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
   <a class="navbar-brand" href="#"><img width="100" height="50" src={download}/></a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>
 
   <div class="collapse navbar-collapse" id="navbarSupportedContent">
     <ul class="navbar-nav mr-auto">
       <li class="nav-item active">
           <Link class="nav-link" to="">Register</Link>
         </li>
     </ul>
     <form class="form-inline my-2 my-lg-0">
       <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><Link to="/login">Login</Link></button>
     </form>
   </div>
 </nav>)
}
export default Header;